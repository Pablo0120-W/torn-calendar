---
name: torn-calendar
description: 将用户照片转化为法国插画家 Kaen 风格的高饱和撞色插画风撕纸拼贴日历。支持单月、多月、整年生成，日历含农历、节气与中国节日。当用户要求"把照片做成日历 / 撕纸风日历 / 插画风日历 / kaen 风日历"时使用本技能。
---

# Torn-Calendar（撕纸风插画风日历）

把用户的照片变成一张（或多张）"撕纸拼贴 + Kaen 高饱和插画风"的日历海报。

## 工作流程

按以下步骤执行，不要跳步：

### 第 1 步：收集参数

支持"零参数直接生成"：用户既不上传照片、也不指定时间时，**不要追问**，直接随机生成——照片随机想象一个风景场景（如雪山湖泊、海岸灯塔、秋日森林、梯田茶山等，从风格适配的高饱和风景题材中任选），时间默认下个月（也可随机任选一月），然后跳到第 2 步。

向用户确认（有缺省时可用默认值）：

| 参数 | 说明 | 默认 |
|---|---|---|
| 照片 | 用户提供的人像/风景/城市照片路径 | **缺省时随机想象一个风景场景，不出现人物** |
| 年份 + 月份 | 支持单月 `2026-03`、连续多月 `2026-03~05`、整年 `2026全年` | **缺省时默认下个月，或随机任选一月** |
| 画幅 | 竖版海报 / 方形 | 竖版 1024×1536 |
| 结构 | L1上下 / L2左图右历 / L3左历右图 / L4图左上历右下 / L5历左上图右下 / L6挖空 / 随机 | **随机**（见第 3 步） |
| 主题短语 | 想印在海报上的短句 | 按月份场景自动生成 |
| 特别标记 | 需要圈出的纪念日（生日、纪念日等） | 无 |

### 第 2 步：生成日历数据

运行脚本生成指定月份的日历数据（含农历、节气、节日）：

```bash
# 首次使用先安装农历依赖（若安装失败见"降级方案"）
pip install lunardate
# 国内网络失败可用镜像：
pip install lunardate -i https://pypi.tuna.tsinghua.edu.cn/simple

# 生成 2026 年 3 月
python scripts/calendar_gen.py 2026 3

# 生成 2026 年 3~5 月
python scripts/calendar_gen.py 2026 3-5

# 生成 2026 全年
python scripts/calendar_gen.py 2026 all
```

脚本会输出一份给生图模型看的 `CALENDAR_TEXT`（要求逐字排版的日历文字，含农历/节气/节日红字标记），以及一份控制台月历块供自查。

**降级方案**：若 `lunardate` 安装失败，运行 `python scripts/calendar_gen.py 2026 3 --no-lunar`，脚本只输出公历+节气+固定节日，并提示你（agent）根据自身知识补全农历日期，补全后必须提醒用户核对农历。

### 第 3 步：抽取画面结构 + 读取模板

核心参考文件为编码存储（`.mdenc`），用解码脚本读取，不要尝试直接打开文件：

```bash
python scripts/decode_refs.py layouts            # 画面结构库
python scripts/decode_refs.py prompt-template    # 生图 Prompt 模板
python scripts/decode_refs.py style-guide        # 风格规范与色板
python scripts/decode_refs.py calendar-spec      # 日历排版规范 + 月份主题表
```

1. 运行 `python scripts/decode_refs.py layouts` 读取画面结构库，从 L1~L5 中**随机抽取一种结构**（如 `python -c "import random; print(random.randint(1,5))"`），取得对应的 `{LAYOUT_BLOCK}` 文本。用户指定了结构则用指定值；L6 挖空式仅在用户明确要求时使用；整年生成默认每月独立随机，用户要求系列统一时锁定同一结构。
2. 运行 `python scripts/decode_refs.py prompt-template` 读取生图模板，将以下内容填入模板占位符：

- `{PHOTO_DESC}`：观察用户照片，描述主体内容（人物姿态、场景、色调）。**人物规则**：照片中有人物时保留其发型、脸型与服装特征（能认出是本人）；照片中无人物时禁止在 prompt 中要求保留人物，且须明确写明"画面中不得出现任何人物"，只做纯风景/场景插画
- `{LAYOUT_BLOCK}`：上一步抽取的结构块
- `{MONTH}` / `{YEAR}` / `{CALENDAR_TEXT}`：来自第 2 步脚本输出
- `{THEME_PHRASE}`：用户指定短语，或按 calendar-spec（`python scripts/decode_refs.py calendar-spec`）的"月份主题表"自动生成
- `{ACCENT_COLORS}`：从 Kaen 色板（`python scripts/decode_refs.py style-guide`）中按月份选择 1 主色 + 1 撞色

### 第 4 步：调用生图模型

- **默认只生成 1 次**，不要主动多次生成
- **模型建议**：优先使用 香蕉模型（nano-banana）或 gpt-image-2，这两者对本 skill 的日历小字与撕纸质感效果最好；仅当平台不支持时再用其他模型
- 尺寸：竖版 `1024x1536`（方形用 `1024x1024`）
- 把用户照片与填好的 prompt 一起发给生图模型（图像编辑/参考图模式）
- 整年生成时：逐月调用，每月共享同一套风格设定，仅 `{ACCENT_COLORS}`、`{CALENDAR_TEXT}`、`{THEME_PHRASE}` 变化，保证 12 张风格统一

### 第 5 步：自检与交付

对每张产出检查：

1. 日历文字是否**逐字正确**（数字、农历、节气不能错、不能多不能少）——文字错误是最常见失败
2. 撕纸毛边、纸张投影是否可见
3. 是否符合 Kaen 高饱和撞色（不是低饱和莫兰迪）
4. 日历区是否被遮挡导致读不清

**重试规则**：只有当上述检查不通过、图片质量确实有问题时才重试，用 prompt-template（`python scripts/decode_refs.py prompt-template`）中的修正话术重新生成；检查全部通过则直接交付，不做多余生成。

## 约束

- 生成的日历文字必须与脚本输出完全一致，禁止自行编造日期
- 节气只出现在对应日期，农历用小字排在公历数字下方
- 每张图一次只做一个月的日历，禁止在一张图里塞多个月
- 风格参考 Kaen 但不复制其具体作品内容，只在 prompt 中描述色彩与画面语言
